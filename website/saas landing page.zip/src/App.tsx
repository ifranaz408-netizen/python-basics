import { useEffect, useRef, useState } from 'react'
import { motion, useInView } from 'framer-motion'
import {
  ArrowRight, BarChart3, Bot, BrainCircuit, Check, ChevronDown, Cloud,
  Code2, FileSearch, Gauge, Headphones, Layers3, LockKeyhole, Menu,
  MessageSquareText, Play, Quote, ShieldCheck, Sparkles, Workflow, X, Zap
} from 'lucide-react'
import './App.css'

const solutions = [
  { icon: Bot, title: 'AI Chatbots', text: 'Deploy intelligent, context-aware assistants that understand your business and delight every customer.' },
  { icon: Workflow, title: 'Workflow Automation', text: 'Turn complex, repetitive processes into reliable autonomous workflows—without operational overhead.' },
  { icon: BrainCircuit, title: 'Predictive Analytics', text: 'Anticipate demand, uncover risks, and make confident decisions with continuously learning models.' },
  { icon: FileSearch, title: 'Document Intelligence', text: 'Extract, classify, and understand information across your entire document ecosystem in seconds.' },
  { icon: Headphones, title: 'Customer Support AI', text: 'Resolve more conversations instantly while giving your team complete context when it matters.' },
  { icon: BarChart3, title: 'Business Intelligence', text: 'Ask questions in natural language and transform fragmented data into clear, actionable insights.' },
]

const features = [
  { icon: Zap, title: 'Fast Performance', text: 'Sub-100ms inference at global scale.' },
  { icon: ShieldCheck, title: 'Enterprise Security', text: 'SOC 2 Type II and GDPR ready.' },
  { icon: Code2, title: 'API Integration', text: 'Elegant SDKs built for your stack.' },
  { icon: Gauge, title: 'Real-time Analytics', text: 'Live intelligence across every model.' },
  { icon: Cloud, title: 'Cloud Deployment', text: 'Deploy anywhere, scale automatically.' },
  { icon: Headphones, title: '24/7 Support', text: 'Expert guidance whenever you need it.' },
]

const faqs = [
  ['How quickly can we deploy Nexora?', 'Most teams launch their first production workflow in under two weeks. Our solutions architects help with architecture, data connections, security review, and rollout.'],
  ['Is our business data used to train your models?', 'Never. Your data remains isolated and encrypted, and is not used to train shared models. Enterprise customers can also select regional data residency.'],
  ['Can Nexora connect to our existing tools?', 'Yes. Nexora offers native connectors for popular CRMs, data warehouses, support platforms, and productivity tools, plus a complete REST API and SDKs.'],
  ['How do you ensure AI outputs are reliable?', 'Every workflow can use grounded retrieval, validation rules, confidence thresholds, evaluations, and human approval steps. You stay in control from prototype to production.'],
  ['Do you support custom models?', 'Yes. Connect leading foundation models, your own fine-tuned models, or use Nexora-managed models through one secure orchestration layer.'],
]

function Counter({ target, suffix = '', decimals = 0 }: { target: number, suffix?: string, decimals?: number }) {
  const ref = useRef<HTMLSpanElement>(null)
  const visible = useInView(ref, { once: true, margin: '-80px' })
  const [value, setValue] = useState(0)
  useEffect(() => {
    if (!visible) return
    const start = performance.now()
    const tick = (now: number) => {
      const p = Math.min((now - start) / 1500, 1)
      setValue(target * (1 - Math.pow(1 - p, 3)))
      if (p < 1) requestAnimationFrame(tick)
    }
    requestAnimationFrame(tick)
  }, [visible, target])
  return <span ref={ref}>{value.toFixed(decimals)}{suffix}</span>
}

const Fade = ({ children, delay = 0, className = '' }: { children: React.ReactNode, delay?: number, className?: string }) => (
  <motion.div className={className} initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-80px' }} transition={{ duration: .65, delay }}>{children}</motion.div>
)

function App() {
  const [menu, setMenu] = useState(false)
  const [openFaq, setOpenFaq] = useState(0)
  const [sent, setSent] = useState(false)

  return (
    <div className="site-shell">
      <nav className="nav-wrap" aria-label="Main navigation">
        <a className="brand" href="#top" aria-label="Nexora home"><span className="brand-mark"><Sparkles size={17}/></span>NEXORA</a>
        <div className="nav-links">
          <a href="#solutions">Solutions</a><a href="#platform">Platform</a><a href="#pricing">Pricing</a><a href="#company">Company</a>
        </div>
        <div className="nav-actions"><a className="login" href="#contact">Sign in</a><a className="button small" href="#contact">Get started <ArrowRight size={15}/></a></div>
        <button className="menu-button" onClick={() => setMenu(!menu)} aria-label="Toggle menu">{menu ? <X/> : <Menu/>}</button>
        {menu && <div className="mobile-menu"><a onClick={()=>setMenu(false)} href="#solutions">Solutions</a><a onClick={()=>setMenu(false)} href="#platform">Platform</a><a onClick={()=>setMenu(false)} href="#pricing">Pricing</a><a onClick={()=>setMenu(false)} href="#contact">Get started</a></div>}
      </nav>

      <main id="top">
        <section className="hero section-pad">
          <div className="hero-grid container">
            <motion.div className="hero-copy" initial={{opacity:0, y:22}} animate={{opacity:1,y:0}} transition={{duration:.8}}>
              <div className="eyebrow"><span></span> AI infrastructure for modern business</div>
              <h1>Intelligence that moves your <em>business forward.</em></h1>
              <p className="hero-sub">Build, automate, and scale intelligent experiences with one secure AI platform—engineered for teams that refuse to stand still.</p>
              <div className="hero-actions"><a className="button" href="#contact">Start building free <ArrowRight size={18}/></a><a className="button ghost" href="#platform"><span className="play"><Play size={13} fill="currentColor"/></span> See the platform</a></div>
              <div className="hero-proof"><div className="avatars"><span>AM</span><span>JL</span><span>SK</span><span>+</span></div><div><b>4.9/5</b><small> Loved by 500+ teams</small></div></div>
            </motion.div>
            <motion.div className="hero-visual" initial={{opacity:0,scale:.92}} animate={{opacity:1,scale:1}} transition={{duration:1,delay:.2}}>
              <div className="orb-glow"></div><img src="/ai-core.png" alt="Luminous neural AI core" />
              <div className="float-card fc-one"><span className="status-dot"></span><div><small>AI PERFORMANCE</small><b>99.9% accuracy</b></div></div>
              <div className="float-card fc-two"><BrainCircuit size={18}/><div><small>AUTOMATIONS</small><b>2,842 active</b></div><span className="trend">+24%</span></div>
            </motion.div>
          </div>
        </section>

        <section className="logos" aria-label="Trusted companies">
          <p>Powering ambitious teams at</p>
          <div className="logo-row"><span><i>◈</i> Vertex</span><span><i>●</i> LUMEN</span><span><i>▲</i> Northstar</span><span><i>✣</i> QUANTUM</span><span><i>⬡</i> Asteria</span><span><i>◆</i> PULSE</span></div>
        </section>

        <section id="solutions" className="section-pad container">
          <Fade className="section-heading"><div className="kicker">BUILT FOR IMPACT</div><h2>One AI platform.<br/><span>Infinite possibilities.</span></h2><p>From the first prototype to millions of decisions, Nexora gives your teams everything they need to put AI to work.</p></Fade>
          <div className="solutions-grid">{solutions.map((s,i)=><Fade key={s.title} delay={i*.06}><article className="solution-card"><div className="icon-box"><s.icon/></div><h3>{s.title}</h3><p>{s.text}</p><a href="#contact" aria-label={`Learn about ${s.title}`}>Explore solution <ArrowRight size={15}/></a></article></Fade>)}</div>
        </section>

        <section id="platform" className="feature-section section-pad">
          <div className="container feature-layout">
            <Fade className="feature-intro"><div className="kicker">ENTERPRISE READY</div><h2>Powerful by default.<br/><span>Effortless by design.</span></h2><p>A production-grade foundation that lets your team move fast—without compromising control, security, or reliability.</p><a href="#contact" className="text-link">Explore our platform <ArrowRight size={16}/></a></Fade>
            <div className="features-grid">{features.map((f,i)=><Fade key={f.title} delay={i*.05}><div className="feature-card"><f.icon/><div><h3>{f.title}</h3><p>{f.text}</p></div></div></Fade>)}</div>
          </div>
        </section>

        <section className="stats container">
          <div><strong><Counter target={500} suffix="+"/></strong><span>Global clients</span></div><div><strong><Counter target={99.9} suffix="%" decimals={1}/></strong><span>Platform uptime</span></div><div><strong><Counter target={10} suffix="M+"/></strong><span>Monthly API requests</span></div><div><strong><Counter target={45} /></strong><span>Countries worldwide</span></div>
        </section>

        <section className="showcase section-pad container">
          <Fade className="section-heading centered"><div className="kicker">CLARITY AT EVERY LEVEL</div><h2>See what your AI is<br/><span>really doing.</span></h2><p>Measure quality, optimize performance, and prove impact with real-time visibility across every workflow.</p></Fade>
          <Fade className="laptop-wrap">
            <div className="laptop">
              <div className="laptop-top"><div className="camera"></div><div className="app-sidebar"><div className="mini-brand"><Sparkles/> NEXORA</div><div className="side-dot active"></div>{[1,2,3,4,5].map(n=><div className="side-dot" key={n}></div>)}</div>
                <div className="dashboard"><div className="dash-header"><div><small>OVERVIEW</small><h3>Good morning, Alex</h3></div><button>Last 30 days <ChevronDown size={12}/></button></div>
                  <div className="dash-stats"><div><small>AI RESOLUTIONS</small><b>24,891</b><em>↗ 18.4%</em></div><div><small>AVG. RESPONSE</small><b>1.24s</b><em>↗ 12.1%</em></div><div><small>COST SAVED</small><b>$84.2k</b><em>↗ 23.7%</em></div></div>
                  <div className="chart-card"><div className="chart-title"><b>Workflow activity</b><span>● Automation &nbsp; <i>● AI agents</i></span></div><div className="chart"><svg viewBox="0 0 800 180" preserveAspectRatio="none"><defs><linearGradient id="fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#7B61FF" stopOpacity=".35"/><stop offset="1" stopColor="#7B61FF" stopOpacity="0"/></linearGradient></defs><path className="area" d="M0 150 C70 130 90 135 140 100 S230 120 280 85 S370 95 420 55 S510 90 570 45 S680 70 800 18 L800 180 L0 180Z"/><path d="M0 150 C70 130 90 135 140 100 S230 120 280 85 S370 95 420 55 S510 90 570 45 S680 70 800 18"/><path className="cyan" d="M0 165 C80 150 110 155 170 130 S260 145 330 112 S420 130 490 95 S590 115 660 78 S730 90 800 62"/></svg></div></div>
                </div>
              </div><div className="laptop-base"></div>
            </div>
          </Fade>
        </section>

        <section id="pricing" className="pricing section-pad">
          <div className="container"><Fade className="section-heading centered"><div className="kicker">SIMPLE, TRANSPARENT PRICING</div><h2>Start small. <span>Scale without limits.</span></h2><p>No hidden fees. No long-term lock-in. Just powerful AI that grows with your business.</p></Fade>
          <div className="pricing-grid">
            <article className="price-card"><span className="plan">STARTER</span><h3>$49<small>/month</small></h3><p>For small teams building their first AI-powered workflows.</p><a href="#contact" className="button ghost">Start free</a><ul>{['5 AI workflows','10,000 actions / month','Core integrations','Community support'].map(x=><li key={x}><Check/>{x}</li>)}</ul></article>
            <article className="price-card featured"><div className="popular">MOST POPULAR</div><span className="plan">PROFESSIONAL</span><h3>$199<small>/month</small></h3><p>For growing teams ready to automate mission-critical work.</p><a href="#contact" className="button">Start free</a><ul>{['Unlimited workflows','100,000 actions / month','Advanced integrations','Analytics & evaluations','Priority support'].map(x=><li key={x}><Check/>{x}</li>)}</ul></article>
            <article className="price-card"><span className="plan">ENTERPRISE</span><h3>Custom</h3><p>For organizations that need control, scale, and dedicated expertise.</p><a href="#contact" className="button ghost">Contact sales</a><ul>{['Unlimited actions','Custom AI models','SSO & advanced security','Dedicated infrastructure','24/7 premium support'].map(x=><li key={x}><Check/>{x}</li>)}</ul></article>
          </div></div>
        </section>

        <section id="company" className="testimonials section-pad container">
          <Fade className="section-heading"><div className="kicker">CUSTOMER STORIES</div><h2>Trusted by teams<br/><span>who move fast.</span></h2></Fade>
          <div className="testimonial-grid">{[
            ['“Nexora gave us the confidence to move AI from experiments into the heart of our operations. We shipped in weeks, not quarters.”','Maya Chen','VP of Product, Vertex'],
            ['“We reduced support resolution time by 64% while improving customer satisfaction. The impact was visible from the first month.”','James Laurent','COO, Northstar'],
            ['“The rare platform that our engineers love and our security team trusts. Nexora has become foundational to how we build.”','Sofia Kostova','CTO, Asteria']
          ].map(([q,n,r],i)=><Fade key={n} delay={i*.08}><article className="quote-card"><Quote/><div className="stars">★★★★★</div><blockquote>{q}</blockquote><div className="person"><span>{n.split(' ').map(x=>x[0]).join('')}</span><div><b>{n}</b><small>{r}</small></div></div></article></Fade>)}</div>
        </section>

        <section className="faq section-pad container">
          <Fade className="faq-intro"><div className="kicker">FAQ</div><h2>Questions, <span>answered.</span></h2><p>Everything you need to know before bringing intelligent automation to your team.</p></Fade>
          <div className="faq-list">{faqs.map(([q,a],i)=><div className={`faq-item ${openFaq===i?'open':''}`} key={q}><button onClick={()=>setOpenFaq(openFaq===i?-1:i)} aria-expanded={openFaq===i}><span>{q}</span><ChevronDown/></button><div className="faq-answer"><p>{a}</p></div></div>)}</div>
        </section>

        <section id="contact" className="contact section-pad">
          <div className="container contact-card"><div className="contact-copy"><div className="kicker">LET'S BUILD WHAT'S NEXT</div><h2>Ready to put AI<br/><span>to work?</span></h2><p>Tell us what you're working on. Our AI solutions team will show you what's possible and map the fastest path to production.</p><div className="contact-points"><span><Check/> Tailored strategy session</span><span><Check/> Custom solution walkthrough</span><span><Check/> No commitment required</span></div></div>
            {sent ? <div className="form-success"><div><Check/></div><h3>You're all set.</h3><p>Thanks for reaching out. Our team will be in touch within one business day.</p><button className="button ghost" onClick={()=>setSent(false)}>Send another message</button></div> :
            <form onSubmit={(e)=>{e.preventDefault();setSent(true)}}><div className="field-row"><label>First name<input required name="first" placeholder="Alex"/></label><label>Last name<input required name="last" placeholder="Morgan"/></label></div><label>Work email<input required type="email" name="email" placeholder="alex@company.com"/></label><label>Company<input required name="company" placeholder="Company name"/></label><label>How can we help?<textarea required name="message" rows={3} placeholder="Tell us about your goals..."/></label><button className="button" type="submit">Talk to an AI expert <ArrowRight/></button></form>}
          </div>
        </section>
      </main>

      <footer><div className="container footer-top"><div className="footer-brand"><a className="brand" href="#top"><span className="brand-mark"><Sparkles size={17}/></span>NEXORA</a><p>The intelligence layer for modern business.</p><div className="socials"><a href="mailto:hello@nexora.ai">in</a><a href="mailto:hello@nexora.ai">𝕏</a><a href="mailto:hello@nexora.ai">◎</a></div></div><div className="footer-links"><div><b>Product</b><a href="#solutions">Solutions</a><a href="#platform">Platform</a><a href="#pricing">Pricing</a></div><div><b>Company</b><a href="#company">About</a><a href="#company">Customers</a><a href="#contact">Careers</a></div><div><b>Resources</b><a href="#platform">Documentation</a><a href="#company">Insights</a><a href="#contact">Support</a></div><div><b>Legal</b><a href="#top">Privacy</a><a href="#top">Terms</a><a href="#top">Security</a></div></div></div><div className="container footer-bottom"><span>© 2025 Nexora AI, Inc. All rights reserved.</span><span className="online"><i></i> All systems operational</span></div></footer>
    </div>
  )
}

export default App
